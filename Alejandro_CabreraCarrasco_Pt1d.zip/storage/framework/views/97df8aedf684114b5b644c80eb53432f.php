<!-- Navigation -->
<nav>
    <a href="<?php echo e(route('home')); ?>">Inici</a>
    &nbsp;&nbsp;&nbsp;
    <a href="<?php echo e(route('llibre_list')); ?>">Llibres</a>
    &nbsp;&nbsp;&nbsp;
    <a href="<?php echo e(route('autor_list')); ?>">Autor</a>
    &nbsp;&nbsp;&nbsp;
    <?php if(Auth::check()): ?>
    <?php echo e($usuari= Auth::user()->name); ?>

    <p>Usuari: <?php echo e($usuari); ?></p>
    <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>

                            <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']); ?>
                                <?php echo e(__('Log Out')); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
                        </form>
        &nbsp;&nbsp;&nbsp;
    <?php else: ?>
        <a href="<?php echo e(route('login')); ?>">Log In</a>
        &nbsp;&nbsp;&nbsp;
        <a href="<?php echo e(route('register')); ?>">Register</a>
    <?php endif; ?>
</nav><?php /**PATH /var/www/html/M7/UF4-Laravel/Pt1d/resources/views/navbar.blade.php ENDPATH**/ ?>