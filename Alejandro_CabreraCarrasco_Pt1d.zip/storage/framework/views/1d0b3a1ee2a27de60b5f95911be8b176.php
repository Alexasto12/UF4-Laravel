<!-- Navigation -->
<nav>
    <a href="<?php echo e(route('home')); ?>">Inici</a>
    &nbsp;&nbsp;&nbsp;
    <a href="<?php echo e(route('llibre_list')); ?>">Llibres</a>
    &nbsp;&nbsp;&nbsp;
    <a href="<?php echo e(route('autor_list')); ?>">Autor</a>
</nav><?php /**PATH /var/www/html/M7/UF2/Pt2a/resources/views/navbar.blade.php ENDPATH**/ ?>