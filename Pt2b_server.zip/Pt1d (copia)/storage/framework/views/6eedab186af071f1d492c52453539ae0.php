<?php $__env->startSection('title', 'Edit Llibre'); ?>

<?php $__env->startSection('stylesheets'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('stylesheets'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Edita el llibre</h1>
    <a href="<?php echo e(route('llibre_list')); ?>">&laquo; Torna</a>
	<div style="margin-top: 20px">
        <form method="POST" action="<?php echo e(route('llibre_edit', $llibre->id )); ?>">
            <?php echo csrf_field(); ?>
            <?php $__errorArgs = ['titol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger" style="color: red"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div>
                <label for="titol">Títol</label>
                <input type="text" name="titol" value="<?php echo e($llibre->titol); ?>" />
            </div>
            <?php $__errorArgs = ['dataP'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger" style="color: red"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div>            
                <label for="dataP">Data de publicació</label>
                <input type="date" name="dataP" value="<?php echo e($llibre->dataP->format('Y-m-d')); ?>"  />
            </div>
            <?php $__errorArgs = ['vendes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger" style="color: red"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div>                            
                <label for="vendes">Vendes</label>
                <input type="number" name="vendes" value="<?php echo e($llibre->vendes); ?>" />
            </div>
            <div>
                <label for="autor_id">Autor</label>
                <select name="autor_id">
                    <?php $__currentLoopData = $autors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <option value="<?php echo e($autor->id); ?>"><?php echo e($autor->nomCognoms()); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit">Actualitzar Llibre</button>
        </form>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/M7/UF4/Pt1/resources/views/llibre/edit.blade.php ENDPATH**/ ?>