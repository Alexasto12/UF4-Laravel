<?php $__env->startSection('title', 'Nou Autor'); ?>

<?php $__env->startSection('stylesheets'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('stylesheets'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Nou Autor</h1>
    <a href="<?php echo e(route('autor_list')); ?>">&laquo; Torna</a>
    <div style="margin-top: 20px">
        <form method="POST" action="<?php echo e(route('autor_new')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div>
                <label for="nom">Nom</label>
                <input type="text" name="nom" value="<?php echo e(old('nom')); ?>" />
                <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger" style="color: red"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>            
                <label for="cognoms">Cognoms</label>
                <input type="text" name="cognoms" value="<?php echo e(old('cognoms')); ?>" />
                <?php $__errorArgs = ['cognoms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"style="color: red"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <input type="file" name="imatge">
            </div>
            <button type="submit">Crear Autor</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/M7/UF2/Pt2d/resources/views/autor/new.blade.php ENDPATH**/ ?>